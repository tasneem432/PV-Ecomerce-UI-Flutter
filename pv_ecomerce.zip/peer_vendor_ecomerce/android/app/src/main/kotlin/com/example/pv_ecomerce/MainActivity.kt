package com.example.pv_ecomerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
